
-- Allow admins to read all profiles
CREATE POLICY "Admins can view all profiles"
ON public.profiles FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Allow admins to read all user_roles
CREATE POLICY "Admins can view all roles"
ON public.user_roles FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Allow admins to read all mentor_sessions
CREATE POLICY "Admins can view all sessions"
ON public.mentor_sessions FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));
