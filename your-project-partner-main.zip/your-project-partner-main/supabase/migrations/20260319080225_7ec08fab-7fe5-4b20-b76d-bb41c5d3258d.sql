
-- Mentor profiles table
CREATE TABLE public.mentor_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  expertise text[] NOT NULL DEFAULT '{}',
  bio text,
  years_experience integer DEFAULT 0,
  hourly_rate numeric(10,2) DEFAULT 0,
  is_available boolean DEFAULT true,
  rating numeric(3,2) DEFAULT 0,
  total_sessions integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.mentor_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view available mentors" ON public.mentor_profiles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Mentors can update their own profile" ON public.mentor_profiles
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Mentors can insert their own profile" ON public.mentor_profiles
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- Mentor sessions / bookings
CREATE TABLE public.mentor_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mentor_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  learner_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  topic text NOT NULL,
  scheduled_at timestamptz NOT NULL,
  duration_minutes integer NOT NULL DEFAULT 60,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','confirmed','completed','cancelled')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.mentor_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own sessions" ON public.mentor_sessions
  FOR SELECT TO authenticated USING (auth.uid() = mentor_id OR auth.uid() = learner_id);

CREATE POLICY "Learners can book sessions" ON public.mentor_sessions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = learner_id);

CREATE POLICY "Participants can update sessions" ON public.mentor_sessions
  FOR UPDATE TO authenticated USING (auth.uid() = mentor_id OR auth.uid() = learner_id);

-- Job postings table
CREATE TABLE public.job_postings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employer_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  company text NOT NULL,
  location text NOT NULL DEFAULT 'Kigali',
  job_type text NOT NULL DEFAULT 'Full-time' CHECK (job_type IN ('Full-time','Part-time','Internship','Contract','Remote')),
  description text NOT NULL,
  requirements text[] DEFAULT '{}',
  salary_range text,
  is_active boolean DEFAULT true,
  applications_count integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.job_postings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can view active jobs" ON public.job_postings
  FOR SELECT TO authenticated USING (is_active = true OR auth.uid() = employer_id);

CREATE POLICY "Employers can insert jobs" ON public.job_postings
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = employer_id);

CREATE POLICY "Employers can update their jobs" ON public.job_postings
  FOR UPDATE TO authenticated USING (auth.uid() = employer_id);

CREATE POLICY "Employers can delete their jobs" ON public.job_postings
  FOR DELETE TO authenticated USING (auth.uid() = employer_id);

-- Job applications table
CREATE TABLE public.job_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES public.job_postings(id) ON DELETE CASCADE NOT NULL,
  applicant_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  cover_letter text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','reviewed','shortlisted','rejected','hired')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(job_id, applicant_id)
);

ALTER TABLE public.job_applications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Applicants can view their applications" ON public.job_applications
  FOR SELECT TO authenticated USING (auth.uid() = applicant_id);

CREATE POLICY "Employers can view applications for their jobs" ON public.job_applications
  FOR SELECT TO authenticated USING (
    EXISTS (SELECT 1 FROM public.job_postings WHERE id = job_id AND employer_id = auth.uid())
  );

CREATE POLICY "Applicants can insert applications" ON public.job_applications
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = applicant_id);

CREATE POLICY "Employers can update application status" ON public.job_applications
  FOR UPDATE TO authenticated USING (
    EXISTS (SELECT 1 FROM public.job_postings WHERE id = job_id AND employer_id = auth.uid())
  );

-- Triggers for updated_at
CREATE TRIGGER update_mentor_profiles_updated_at
  BEFORE UPDATE ON public.mentor_profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_job_postings_updated_at
  BEFORE UPDATE ON public.job_postings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
